Source code for the [Straightforward Rails Authorization with Pundit](http://www.sitepoint.com/straightforward-rails-authorization-with-pundit/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).

[Working demo](https://sitepoint-pundit.herokuapp.com/).