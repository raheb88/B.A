Clearance.configure do |config|
  config.mailer_sender = "reply@example.com"
end
