class PaymentHistory < ApplicationRecord
  belongs_to :purse
end
