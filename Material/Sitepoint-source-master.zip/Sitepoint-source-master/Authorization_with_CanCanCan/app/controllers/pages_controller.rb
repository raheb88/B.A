class PagesController < ApplicationController
  skip_authorization_check

  def index
  end
end