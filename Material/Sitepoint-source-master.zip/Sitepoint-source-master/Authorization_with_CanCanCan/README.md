Source code for the [CanCanCan: The Rails Authorization Dance](http://www.sitepoint.com/cancancan-rails-authorization-dance/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).

[Working demo](https://sitepoint-cancan.herokuapp.com/).



