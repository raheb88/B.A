class Oauth::TokenController < Opro::Oauth::TokenController
end