class Oauth::AuthController < Opro::Oauth::AuthController
end