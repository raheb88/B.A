Source code for the [Authenticate All the Things with oPRO, the Basics](http://www.sitepoint.com/authenticate-all-the-things-with-opro-the-basics/),
[OAuth 2 All the Things with oPRO: Users and API](http://www.sitepoint.com/oauth-2-all-the-things-with-opro-users-and-api/)
and [OAuth 2 All the Things with oPRO: Customization](http://www.sitepoint.com/oauth-2-all-the-things-with-opro-customization/) articles on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).