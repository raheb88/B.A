Source code for the [Rails Authentication with Authlogic](http://www.sitepoint.com/rails-authentication-with-authlogic/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).

[Working demo](https://sitepoint-authlogic.herokuapp.com/).