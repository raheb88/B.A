Source code for the [Simple Rails Authentication with Clearance](http://www.sitepoint.com/simple-rails-authentication-with-clearance/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).

[Working demo](https://sitepoint-clearance.herokuapp.com/).



