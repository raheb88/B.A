Source code for the [Zip It! Zip It Good with Rails and Rubyzip](http://www.sitepoint.com/accept-and-send-zip-archives-with-rails-and-rubyzip/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).