Source code for the [Rails Authentication with OAuth 2.0 and OmniAuth](http://www.sitepoint.com/rails-authentication-oauth-2-0-omniauth/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).

[Working demo](https://sitepoint-oauth2.herokuapp.com/).



