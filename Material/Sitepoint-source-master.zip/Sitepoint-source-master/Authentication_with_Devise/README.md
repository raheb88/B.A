Source code for the [Devise Authentication in Depth](http://www.sitepoint.com/devise-authentication-in-depth/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).

[Working demo](https://sitepoint-devise.herokuapp.com/).