Source code for the [Getting Started with Doorkeeper and OAuth 2.0](http://www.sitepoint.com/getting-started-with-doorkeeper-and-oauth-2-0/),
and [Tailor Doorkeeper with Refresh Tokens, Views, and Strategies](http://www.sitepoint.com/tailor-doorkeeper-with-refresh-tokens-views-and-strategies/) articles on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).