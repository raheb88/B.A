Source code for the [Search and Autocomplete in Rails Apps](https://www.sitepoint.com/search-autocomplete-rails-apps/) article on
SitePoint,
created by Ilya Bodrov ([bodrovis.tech](http://bodrovis.tech)).
