class CitiesController < ApplicationController
  def index
  end
end