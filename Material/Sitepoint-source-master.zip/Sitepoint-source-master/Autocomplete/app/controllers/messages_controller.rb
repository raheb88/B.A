class MessagesController < ApplicationController
  def new
  end
end